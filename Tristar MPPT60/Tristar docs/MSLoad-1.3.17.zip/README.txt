MSLoad v1.3.xx
Firmware utility for Morningstar charge controllers, inverters, and accessories.
Morningstar Corporation
November 2016


Usage - Charge controllers, inverters, Relay Driver, etc:
1. Download the latest firmware file for the product. Morningstar firmware files have the extension: *.msc
2. Power off the controller/inverter
3. Connect the PC to the controller/inverter with a straight-through serial cable.
4. Drag and drop the *.msc file onto the MSLoad program icon. This will automatically launch MSView with the correct firmware file already selected in Step 1.
Alternatively, open MSLoad and specify the firmware file location in Step 1.
5. Follow the on-screen instructions, selecting the correct COM port and then turning on the controller/inverter when prompted.
6. If the firmware update was successful, a green check mark will be displayed. If a red "X" is displayed, see troubleshooting below.



Usage - Meters
To load firmware into a TriStar Meter or TriStar Meter 2
1. Download the latest firmware file for the product. Morningstar firmware files have the extension: *.msc
2. Connect the PC to the TriStar or TriStar MPPT with a straight-through serial cable. Keep the unit powered on.
3. Drag and drop the *.msc file onto the MSLoad program icon. This will automatically launch MSView with the correct firmware file already selected in Step 1.
   Alternatively, open MSLoad and specify the firmware file location in Step 1.
4. Follow the on-screen instructions, selecting the correct COM port, Modbus ID of the TriStar.
5. Connect the meter to the meter port on the controller with an RJ-11 cable when prompted by MSLoad.
6. If the firmware update was successful, a green check mark will be displayed. If a red "X" is displayed, see troubleshooting below.




Troubleshooting
If the firmware update was not successful, a red "X" will be displayed.
Try the process a second time. If it fails again, check the following:

1. Be sure you have selected the correct COM port. If using a USB to Serial cable, be sure the cable drivers are installed correctly. 
Confirm that a COM port has been mapped to the cable in the Windows Device Manager (under the Ports node) and that you specified the correct COM port in MSLoad.
Many USB-serial adapter cables have LEDs that blink when data is transmitted. Verify that the cable LED blinks when MSView is attempting to load firmware. If not,
there is likely an issue with the cable.


2. Try a different serial cable. The cable should be a straight-through type cable. A Null Modem cross-over cable will not work.

3. Try a different PC.

If the firmware update still fails, contact Morningstar Support for more information. Contact info is available on our website.